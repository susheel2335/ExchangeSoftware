  <nav class="navbar navbar-expand-md navbar-dark bg-primary  fixed-top  customsizeadded">
 
  <div class="navbar-header">
                    
						
						
						<a class="navbar-brand" href="#">
          <img src="/assets/images/logo/1.png" alt="">
        </a>
        
        
		
		</div>
                        <!--End Logo icon -->
                        <!-- Logo text --><span>
                         <!-- dark Logo text -->
                         
                         
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarsExampleDefault">
  
  
  <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="#">Dashboard <span class="sr-only">(current)</span></a>
      </li>
      
      
         <li class="nav-item">   <a class="nav-link"   href="/system/account">Accounts</a></li>
		 
		     
           <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="dropdown01" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Exchange </a>
        <div class="dropdown-menu" aria-labelledby="dropdown01">
          <a class="dropdown-item" href="/trade/BTC/BRL">BTC / brazilian REAL</a>
          <a class="dropdown-item" href="/trade/BTC/COL">BTC / Colombia pesos</a>
          <a class="dropdown-item" href="/trade/BTC/globocoins">BTC / Globocoins</a>
          
            <a class="dropdown-item" href="/trade/BTC/USD ">BTC / USD </a>
            
              <a class="dropdown-item" href="/trade/BTC/EUR">BTC / EUR</a>
              
                <a class="dropdown-item" href="/trade/BTC/JPY">BTC / JPY</a>
               
              <a class="dropdown-item" href="/trade/USD/WIBX">USD / WIBX</a>
              
                <a class="dropdown-item" href="/trade/WIBX/BRL">WIBX / BRL</a>
                
                
                <a class="dropdown-item" href="/trade/QTUM/USD">QTUM/USD</a>
        </div>
      </li>
      
      
	   
	    
       
	   
       
    
    <li  class="nav-item">
        
        
    <a  class="nav-link" href="/auth/profile">Profile</a>
    </li>
    
    
    
    
    <li class="nav-item dropdown">
       
       
        <a class="nav-link dropdown-toggle" href="#" id="dropdown01"
        data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Other menu</a>
        
        
        <div class="dropdown-menu" aria-labelledby="dropdown01">
        
             
    <a  class="dropdown-item"  href="/system/deposits">Deposits</a>
    <a class="dropdown-item"  href="/system/widthdraw">Widthdraw</a> 
    <a  class="dropdown-item" href="/auth/profile">Profile</a>
    
     <a class="dropdown-item" href="/system/transactions">Transactions</a>
     
         
        </div>
      </li>
    
     
    
    <li   class="nav-item"><a class="nav-link" href="/logout">Logout</a> </li>
    
    </ul>
	
	
    <ul class="navbar-nav mr-auto">
        
              
 
    </ul>
  
  </div>
</nav>
