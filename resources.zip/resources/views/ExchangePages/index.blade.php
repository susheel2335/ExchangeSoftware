@extends('exchange')
@section('content')

..............................
@endsection