@extends('design1layout')
@section('content')

  <div class="container">

      <div class="row">
        <div class="col-md-12">
            
            <h3>   <center>  Investment Order History   </center>   </h3>
            
            
            <table class="table table-hover" >
 <tr> 
     <td> Order ID</td>
     <td>Package Name</td>
     <td>Coin</td>
     <td>Amount</td>
     <td>Status</td>
     
      <td>Created At</td>
     </tr> 
 
@foreach ($mlm_investment_orders as $dt)
    <tr>  
    
    <td>   {{ $dt->id }}</td>
    
    
    <td>   {{ $dt->package_name }}</td>
    <td>   {{ $dt->coin }}</td>
    
    <td>   {{ $dt->amount }}</td>
     
    
    <td>   {{ $dt->status }}</td>  
    
         <td>   {{ $dt->created_at }}</td>
         
    </tr>
    
    
@endforeach

</table>
  </div></div></div>
@endsection