@extends('design1layout')
@section('content')

  <div class="container">

      <div class="row">
        <div class="col-md-12">
            
            <h3>   <center> mlm_investment_transactions Earning Report  </center>   </h3>
            
            
            <table class="table table-hover" >
 <tr> 
     <td>  ID</td> <td>Investment Order ID</td>
     <td>Description</td>
     <td>Credit Amount</td>
     <td>Debit Amount</td>
    
     <td>Coin</td>
     <td>Status</td>
     
      <td>Created At</td>
     </tr> 
 
@foreach ($mlm_investment_transactions as $dt)
    <tr>  
    
    <td>   {{ $dt->id }}</td>
     <td>   {{ $dt->order_id }}</td>
     <td>   {{ $dt->description }}</td>
    <td>   {{ $dt->cr }}</td>
    <td>   {{ $dt->dr }}</td>
    
   
    
    
    <td>   {{ $dt->coin }}</td>
     
     
    
    <td>   {{ $dt->status }}</td>  
    
         <td>   {{ $dt->created_at }}</td>
         
    </tr>
    
    
@endforeach

</table>
  </div></div></div>
@endsection