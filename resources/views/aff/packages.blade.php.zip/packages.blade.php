@extends('design1layout')
@section('content')
    

 <center><h3>Our packages</h3></center>
 
 
 <center><h3>Your current package is {{ Session::get('package_name') }}   </h3></center>
               
               
               
<div class="row">
@foreach ($packages as $dt)

<div class="col"><div class="card" style="width: 18rem;">
  <img src="https://www.evansinvestmentcounsel.com/wp-content/uploads/2017/04/philosophy-wealth-management.jpg" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">{{ $dt['name'] }}</h5>
    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
    <p class="card-text">{{ $dt['invest'] }} USD</p>
    
     
    <form action="investnow"   method="post">
   
  
         @csrf

    <input type="hidden" class="form-control" value="{{ $dt['invest'] }}" name="plan">
    
    
    <input type="hidden" class="form-control" value="{{ $dt['name'] }}" name="package_name">
     
    <select class="form-control" name="payment_method">
  <option value="BTC">Bitcoin </option>
    <option  value="ETH">Ethereum</option>
    <option  value="BCH">Bitcoin Cash</option>
     
   
        
</select>
 
  <button type="submit" class="btn btn-primary">Invest Now</button>
</form>


    
    
  </div>
</div></div>



    
    
    
@endforeach 
       
</div>
@endsection